// plugins/q5-tools.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - قسم الأدوات 🛠️

import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';
import { theme } from '../core/theme.js';

let handler = async (m, { conn, usedPrefix: _p }) => {
  try {
    const user = await conn.getName(m.sender);
    
    // ⬇️ أوامر قسم الأدوات
    let menuText = `> ${theme.divider}
>
> 🜲⃝☠️ *أهـلاً بـك يـا:* ${user}
> 𖤐⃝🩸 *الـقـسـم:* قسم الأدوات
>
> ${theme.smallDivider}
>
> 👁️⃝🩸 *الأوامر المتاحة:*
>
> 🛠️⃝🩸 *.كشف* 
> 🛠️⃝🩸 *.تحسين* 
> 🛠️⃝🩸 *.رفع* 
> 🛠️⃝🩸 *.رابط* 
> 🛠️⃝🩸 *.سكرب* 
> 🛠️⃝🩸 *.لفيديو* 
> 🛠️⃝🩸 *.لصوره* 
> 🛠️⃝🩸 *.لصوت* 
> 🛠️⃝🩸 *.لكرتون* 
> 🛠️⃝🩸 *.ارسم* 
> 🛠️⃝🩸 *.اختصار* 
> 🛠️⃝🩸 *.ترجم* 
> 🛠️⃝🩸 *.حلل* 
>
> ${theme.smallDivider}
>
> 📌 *طريقة الاستخدام:*
> 👁️⃝🩸 اكتب اسم الأداة واتبع التعليمات
>
> ${theme.endDivider}`;

    await conn.sendMessage(m.chat, { react: { text: '🛠️', key: m.key } });

    // الصورة الجديدة لقسم الأدوات
    const imageUrl = 'https://file.garden/aauvg01sjleV_ic1/NoteGPT_Image_20260522210127.png';
    const imageRes = await fetch(imageUrl);
    const imageBuffer = Buffer.from(await imageRes.arrayBuffer());
    const media = await prepareWAMessageMedia({ image: imageBuffer }, { upload: conn.waUploadToServer });
    
    const nativeFlowPayload = {
      body: { text: menuText },
      footer: { text: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2' },
      header: {
        hasMediaAttachment: true,
        subtitle: '🛠️ قـسـم الأدوات',
        imageMessage: media.imageMessage
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '🔙 الـعـودة للـقـائـمـة',
              id: '.الاوامر'
            })
          },
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '👑 الـمـطـور',
              id: '.المطور'
            })
          }
        ],
        messageParamsJson: JSON.stringify({
          bottom_sheet: {
            in_thread_buttons_limit: 1,
            list_title: "🛠️ قـسـم الأدوات",
            button_title: "خـيـارات"
          }
        })
      }
    };

    const interactiveMessage = proto.Message.InteractiveMessage.fromObject(nativeFlowPayload);
    const fkontak = await makeFkontak();
    const msg = generateWAMessageFromContent(m.chat, { interactiveMessage }, { 
      userJid: conn.user.jid, 
      quoted: fkontak 
    });
    
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

  } catch (e) {
    console.error(e);
    await conn.sendMessage(m.chat, { 
      text: theme.build([
        { type: 'title', text: 'خـطـأ' },
        { type: 'subtitle', text: 'حدث خطأ في تحميل قسم الأدوات' }
      ])
    }, { quoted: m });
  }
}

async function makeFkontak() {
  try {
    const res = await fetch('https://file.garden/aauvg01sjleV_ic1/a2075690da240b4d4af5e9affed48bbe.jpg');
    const thumb2 = Buffer.from(await res.arrayBuffer());
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2', jpegThumbnail: thumb2 } },
      participant: '0@s.whatsapp.net'
    };
  } catch {
    return undefined;
  }
}

handler.help = ['ق5'];
handler.tags = ['main'];
handler.command = ['ق5'];

export default handler;