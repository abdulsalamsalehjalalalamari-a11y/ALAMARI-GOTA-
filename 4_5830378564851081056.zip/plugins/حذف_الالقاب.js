// plugins/delete_all_lakab.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - حذف جميع ألقاب المجموعة 👥

let handler = async function (m, { conn }) {
    try {
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        const groupId = m.chat;
        
        // الحصول على معلومات المجموعة
        let groupInfo;
        try {
            groupInfo = await conn.groupMetadata(groupId);
        } catch (e) {
            return m.reply(`❌ فشل في الوصول لبيانات المجموعة. تأكد من أن البوت أدمن.`);
        }

        const groupMembers = groupInfo.participants;
        
        // التأكد من وجود قاعدة البيانات
        if (!global.db?.data?.users) {
            return m.reply(`❌ قاعدة البيانات غير جاهزة`);
        }
        
        const users = global.db.data.users;

        // تصفية المستخدمين الذين يملكون ألقاباً في هذه المجموعة
        const usersWithNicknames = [];
        
        for (let [jid, user] of Object.entries(users)) {
            if (user.groups?.[groupId]?.name) {
                usersWithNicknames.push({ 
                    jid: jid, 
                    name: user.groups[groupId].name,
                    user: user
                });
            }
        }

        if (usersWithNicknames.length === 0) {
            await conn.sendMessage(m.chat, { react: { text: 'ℹ️', key: m.key } });
            return m.reply(`⚠️ لا توجد ألقاب مسجلة في هذه المجموعة حالياً.`);
        }

        // حذف جميع الألقاب
        let deletedNames = [];
        for (let item of usersWithNicknames) {
            deletedNames.push(item.name);
            delete item.user.groups[groupId].name;
            
            // حفظ التغيير لكل مستخدم
            if (global.db.writeData) {
                await global.db.writeData('users', item.jid, item.user).catch(() => {});
            }
        }

        // بناء رسالة النتيجة
        let resultMessage = `╭━━ 👥 *تطهير الألقاب* ━━⃝💙
│
│ 🧹 *تم حذف جميع الألقاب في المجموعة*
│
│ 📊 *الإحصائيات النهائية:*
│ • عدد الألقاب المحذوفة: ${usersWithNicknames.length}
│ • عدد أعضاء المجموعة: ${groupMembers.length}
│
│ 🏷️ *الألقاب المحذوفة:*
${deletedNames.map((name, i) => `│ ${i + 1}. ${name}`).join('\n')}
│
╰━━━━━━━━━━━━━⃝💙`;

        await conn.sendMessage(m.chat, { text: resultMessage }, { quoted: m });
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error('حذف_الألقاب error:', err);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await m.reply(`❌ حدث خطأ: ${err.message || err}`);
    }
};

handler.help = ['حذف_الألقاب'];
handler.tags = ['unions'];
handler.command = /^(حذف_الألقاب|حذف_الالقاب|delete_all)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;