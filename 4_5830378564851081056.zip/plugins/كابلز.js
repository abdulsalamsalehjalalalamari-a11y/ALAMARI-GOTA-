// plugins/couplepp.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - صور كابلز (ولد + بنت) 💑👫

import fetch from "node-fetch";
import { theme } from '../core/theme.js';

let handler = async (m, { conn }) => {
  try {
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    // جلب قاعدة بيانات الصور من GitHub
    let res = await fetch("https://raw.githubusercontent.com/KazukoGans/database/main/anime/ppcouple.json");
    let data = await res.json();

    if (!Array.isArray(data) || data.length === 0) {
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      return m.reply(theme.build([
        { type: 'error', text: '❌ لم يتم العثور على بيانات الكابلز' }
      ]));
    }

    // اختيار زوج عشوائي من الصور (ولد + بنت)
    let cita = data[Math.floor(Math.random() * data.length)];

    // إرسال صورة الولد
    await conn.sendMessage(m.chat, {
      image: { url: cita.cowo },
      caption: theme.build([
        { type: 'title', text: '👦 صورة الولد' },
        { type: 'line', text: '👫 كابلز - زوج من الصور' }
      ])
    }, { quoted: m });

    // إرسال صورة البنت
    await conn.sendMessage(m.chat, {
      image: { url: cita.cewe },
      caption: theme.build([
        { type: 'title', text: '👧 صورة البنت' },
        { type: 'line', text: '👫 كابلز - زوج من الصور' }
      ])
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (err) {
    console.error(err);
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    m.reply(theme.build([
      { type: 'error', text: '❌ حدث خطأ أثناء تحميل الصور' },
      { type: 'info', label: 'السبب', value: err.message || 'خطأ غير معروف' }
    ]));
  }
};

handler.help = ['كابيلز'];
handler.tags = ['images'];
handler.command = /^(كابيلز|couplepp|تطقيم)$/i;

export default handler;