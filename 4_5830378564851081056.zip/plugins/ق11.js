// commands/ق11.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - قسم المطور 🔧 (للمطور فقط)

import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';
import { theme } from '../core/theme.js';

let handler = async (m, { conn, usedPrefix: _p, isROwner, isOwner }) => {
  // ✅ التحقق: إذا كان المستخدم ليس مطور (لا isROwner ولا isOwner) → لا يحدث شيء نهائياً
  if (!isROwner && !isOwner) {
    return; // بكل بساطة، ما يردش خالص، ولا رسالة ولا تفاعل ولا شيء
  }

  // 🟢 من هنا الكود يشتغل فقط للمطور
  try {
    const user = await conn.getName(m.sender);
    
    // ⬇️ أوامر قسم المطور
    let menuText = `> ${theme.divider}
>
> 🜲⃝☠️ *أهـلاً بـك يـا:* ${user}
> 𖤐⃝🩸 *الـقـسـم:* قسم المطور 🔧
>
> ${theme.smallDivider}
>
> 👁️⃝🩸 *الأوامر المتاحة:*
>
> ⚙️⃝🔧 *${_p}بلوقن* 
> 📋⃝🔧 *${_p}بلوقن لست* 
> 👁️⃝🔧 *${_p}بلوقن عرض* 
> 🗑️⃝🔧 *${_p}بلوقن حذف* 
> 🖥️⃝🔧 *${_p}بنج* 
> 🚫⃝🔧 *${_p}حظر_جروب* 
> 🚪⃝🔧 *${_p}اطلع* 
> 📜⃝🔧 *${_p}اخر30* 
> 💻⃝🔧 *${_p}كود* 
> 🔍⃝🔧 *${_p}بصمه* 
> ⚡⃝🔧 *${_p}تنفيذ* 
> 📤⃝🔧 *${_p}بوست* 
> 🔄⃝🔧 *${_p}اعاده* 
> 📊⃝🔧 *${_p}لفل_اب* 
> 📜⃝🔧 *${_p}سكربتي*
> 🐦 🔧*${_p}هش*
>
> ${theme.smallDivider}
>
> ⚠️ *ملاحظة مهمة:* 
> 👁️⃝🩸 جميع الأوامر التالية *للمطور فقط*
> 🚫⃝🩸 غير مصرح للمستخدمين العاديين باستخدامها
>
> ${theme.endDivider}`;

    await conn.sendMessage(m.chat, { react: { text: '🔧', key: m.key } });

    // صورة قسم المطور
    const imageUrl = 'https://file.garden/aauvg01sjleV_ic1/ce2eb4798f2846badd0327a2a2e060bf.jpg';
    const imageRes = await fetch(imageUrl);
    const imageBuffer = Buffer.from(await imageRes.arrayBuffer());
    const media = await prepareWAMessageMedia({ image: imageBuffer }, { upload: conn.waUploadToServer });
    
    const nativeFlowPayload = {
      body: { text: menuText },
      footer: { text: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2' },
      header: {
        hasMediaAttachment: true,
        subtitle: '🔧 قـسـم المطور',
        imageMessage: media.imageMessage
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '🔙 الـعـودة للـقـائـمـة',
              id: '.الاوامر'
            })
          },
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '👑 الـمـطـور',
              id: '.المطور'
            })
          }
        ],
        messageParamsJson: JSON.stringify({
          bottom_sheet: {
            in_thread_buttons_limit: 1,
            list_title: "🔧 قـسـم المطور",
            button_title: "خـيـارات"
          }
        })
      }
    };

    const interactiveMessage = proto.Message.InteractiveMessage.fromObject(nativeFlowPayload);
    const fkontak = await makeFkontak();
    const msg = generateWAMessageFromContent(m.chat, { interactiveMessage }, { 
      userJid: conn.user.jid, 
      quoted: fkontak 
    });
    
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

  } catch (e) {
    console.error(e);
    // حتى الخطأ يظهر للمطور فقط (لأن الكود مش هيدخل هنا لو مش مطور أصلاً)
    await conn.sendMessage(m.chat, { 
      text: theme.build([
        { type: 'title', text: 'خـطـأ' },
        { type: 'subtitle', text: 'حدث خطأ في تحميل قسم المطور' }
      ])
    }, { quoted: m });
  }
}

async function makeFkontak() {
  try {
    const res = await fetch('https://file.garden/aauvg01sjleV_ic1/a2075690da240b4d4af5e9affed48bbe.jpg');
    const thumb2 = Buffer.from(await res.arrayBuffer());
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2', jpegThumbnail: thumb2 } },
      participant: '0@s.whatsapp.net'
    };
  } catch {
    return undefined;
  }
}

handler.help = ['ق11'];
handler.tags = ['main'];
handler.command = ['ق11'];
handler.rowner = true;  // يمنع غير المطور من استخدام الأمر

export default handler;