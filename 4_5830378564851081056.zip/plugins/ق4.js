// plugins/q4-download.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - قسم التحميل 📥

import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';
import { theme } from '../core/theme.js';

let handler = async (m, { conn, usedPrefix: _p }) => {
  try {
    const user = await conn.getName(m.sender);
    
    // ⬇️ أوامر قسم التحميل
    let menuText = `> ${theme.divider}
>
> 🜲⃝☠️ *أهـلاً بـك يـا:* ${user}
> 𖤐⃝🩸 *الـقـسـم:* قسم التحميل
>
> ${theme.smallDivider}
>
> 👁️⃝🩸 *الأوامر المتاحة:*
>
> 📦⃝🩸 *.apk* 
> 📷⃝🩸 *.انستا* 
> 📘⃝🩸 *.فيس* 
> 🎵⃝🩸 *.تيك* 
> 🖼️⃝🩸 *.بينتر* 
> 📁⃝🩸 *.ميديا_فاير* 
> 💻⃝🩸 *.جيتهاب* 
> 🎬⃝🩸 *.ايديت* 
> ▶️⃝🩸 *.يوتيوب*
> 🎧⃝🩸 *.سبوتيفاي*
> 🎙️⃝🩸 *.صوت* 
> 🎧⃝🩸 *.اغنيه* 
> ☁️⃝🩸 *.تيرابوكس* 
>
> ${theme.smallDivider}
>
> 📌 *طريقة الاستخدام:*
> 👁️⃝🩸 أرسل الأمر مع الرابط أو اسم الملف
>
> ${theme.endDivider}`;

    await conn.sendMessage(m.chat, { react: { text: '📥', key: m.key } });

    // 🔥 الصورة الجديدة لقسم التحميل
    const imageUrl = 'https://file.garden/aauvg01sjleV_ic1/0b065522627a45209586635da7c6fbde.png';
    const imageRes = await fetch(imageUrl);
    const imageBuffer = Buffer.from(await imageRes.arrayBuffer());
    const media = await prepareWAMessageMedia({ image: imageBuffer }, { upload: conn.waUploadToServer });
    
    const nativeFlowPayload = {
      body: { text: menuText },
      footer: { text: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2' },
      header: {
        hasMediaAttachment: true,
        subtitle: '📥 قـسـم الـتـحـمـيـل',
        imageMessage: media.imageMessage
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '🔙 الـعـودة للـقـائـمـة',
              id: '.الاوامر'
            })
          },
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '👑 الـمـطـور',
              id: '.المطور'
            })
          }
        ],
        messageParamsJson: JSON.stringify({
          bottom_sheet: {
            in_thread_buttons_limit: 1,
            list_title: "📥 قـسـم الـتـحـمـيـل",
            button_title: "خـيـارات"
          }
        })
      }
    };

    const interactiveMessage = proto.Message.InteractiveMessage.fromObject(nativeFlowPayload);
    const fkontak = await makeFkontak();
    const msg = generateWAMessageFromContent(m.chat, { interactiveMessage }, { 
      userJid: conn.user.jid, 
      quoted: fkontak 
    });
    
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

  } catch (e) {
    console.error(e);
    await conn.sendMessage(m.chat, { 
      text: theme.build([
        { type: 'title', text: 'خـطـأ' },
        { type: 'subtitle', text: 'حدث خطأ في تحميل قسم التحميل' }
      ])
    }, { quoted: m });
  }
}

async function makeFkontak() {
  try {
    const res = await fetch('https://file.garden/aauvg01sjleV_ic1/a2075690da240b4d4af5e9affed48bbe.jpg');
    const thumb2 = Buffer.from(await res.arrayBuffer());
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2', jpegThumbnail: thumb2 } },
      participant: '0@s.whatsapp.net'
    };
  } catch {
    return undefined;
  }
}

handler.help = ['ق4'];
handler.tags = ['main'];
handler.command = ['ق4'];

export default handler;