// plugins/personality.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - تحليل الشخصية 🎭

import { theme } from '../core/theme.js';

let handler = async (m, { conn, command, text, usedPrefix }) => {

    // تحديد الاسم المستهدف
    let targetName = '';
    
    if (m.mentionedJid && m.mentionedJid[0]) {
        try {
            targetName = await conn.getName(m.mentionedJid[0]);
        } catch {
            targetName = m.mentionedJid[0].split('@')[0];
        }
    } else if (m.quoted && m.quoted.sender) {
        try {
            targetName = await conn.getName(m.quoted.sender);
        } catch {
            targetName = m.quoted.sender.split('@')[0];
        }
    } else if (text && text.trim()) {
        targetName = text.trim();
    } else {
        await conn.sendMessage(m.chat, { react: { text: '✍️', key: m.key } });
        return m.reply(theme.build([
            { type: 'title', text: '🎭 تحليل الشخصية' },
            { type: 'spacer' },
            { type: 'warning', text: 'قم بمنشن الشخص أو كتابة اسمه أو رد على رسالته' },
            { type: 'info', label: 'مثال', value: `${usedPrefix + command} @user` },
            { type: 'info', label: 'مثال', value: `${usedPrefix + command} محمد` }
        ]));
    }

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    let stats = ['6%','12%','20%','35%','41%','49%','54%','60%','73%','84%','92%','99%','1%','0%'];
    
    let personalidad = theme.build([
        { type: 'title', text: `🎭 تحليل شخصية: ${targetName}` },
        { type: 'spacer' },
        { type: 'info', label: '📊 المعنويات', value: pickRandom(stats) },
        { type: 'info', label: '📉 الأخلاق', value: pickRandom(stats) },
        { type: 'info', label: '🧠 الذكاء', value: pickRandom(stats) },
        { type: 'info', label: '🔥 الشجاعة', value: pickRandom(stats) },
        { type: 'info', label: '🎭 الشهرة', value: pickRandom(stats) },
        { type: 'info', label: '🔞 الانحراف', value: pickRandom(stats) },
        { type: 'divider' },
        { type: 'info', label: '🧩 نوع الشخصية', value: pickRandom(['ذو قلب طيب', 'متعجرف', 'سخي', 'متواضع', 'خجول', 'فضولي', 'ذكي جداً', 'هادئ', 'مغامر', 'حساس']) },
        { type: 'info', label: '⏳ الحالة الدائمة', value: pickRandom(['مشتت الانتباه', 'يشاهد الأنمي', 'على الهاتف دائماً', 'يفكر في المستقبل', 'يضيع الوقت', 'مبدع', 'نشيط', 'كسول']) },
        { type: 'info', label: '🚻 التوجه', value: pickRandom(['رجل', 'امرأة', 'مستقيم', 'فضائي 👽', 'شخصية أسطورية']) }
    ]);

    await conn.sendMessage(m.chat, { text: personalidad }, { quoted: m });
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
};

handler.help = ['شخصية'];
handler.tags = ['fun'];
handler.command = /^(شخصية|شخصيه|تحليل)$/i;

export default handler;

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
}