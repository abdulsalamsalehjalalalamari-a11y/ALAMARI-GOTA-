// plugins/delete_lakab.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - حذف لقب عضو في المجموعة 👥

let handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
        let mentionedJid;

        // تحديد العضو المستهدف
        if (m.quoted && m.quoted.sender) {
            mentionedJid = m.quoted.sender;
        } else if (text) {
            const number = text.replace(/[^0-9]/g, '');
            if (number) {
                mentionedJid = number + '@s.whatsapp.net';
            }
        }

        if (!mentionedJid) {
            return m.reply(`✍️ *طريقة الاستخدام:*\n${usedPrefix + command} @العضو\nأو قم بالرد على رسالة العضو`);
        }

        // التأكد من وجود قاعدة البيانات
        if (!global.db?.data?.users) {
            return m.reply(`❌ قاعدة البيانات غير جاهزة`);
        }

        const users = global.db.data.users;
        let user = users[mentionedJid];

        if (!user || !user.groups || !user.groups[m.chat] || !user.groups[m.chat].name) {
            return m.reply(`⚠️ هذا العضو لا يملك لقباً مسجلاً في هذه المجموعة.`);
        }

        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const oldName = user.groups[m.chat].name;
        delete user.groups[m.chat].name;

        // حفظ التغيير في قاعدة البيانات
        if (global.db.writeData) {
            await global.db.writeData('users', mentionedJid, user).catch(() => {});
        }

        let memberName = mentionedJid.split('@')[0];
        try {
            const nameFromConn = await conn.getName(mentionedJid);
            if (nameFromConn) memberName = nameFromConn;
        } catch(e) {}

        let successMsg = `╭━━ 👥 *حذف لقب* ━━⃝💙
│
│ ✅ *تم حذف اللقب بنجاح*
│
│ 👤 *العضو:* ${memberName}
│ 🏷️ *اللقب المحذوف:* ${oldName}
│
╰━━━━━━━━━━━━━⃝💙`;

        await conn.sendMessage(m.chat, { text: successMsg, mentions: [mentionedJid] }, { quoted: m });
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error('حذف_لقب error:', err);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await m.reply(`❌ حدث خطأ: ${err.message || err}`);
    }
};

handler.help = ['حذف_لقب'];
handler.tags = ['unions'];
handler.command = /^(حذف-لقب|حذف_لقب|delete_lakab)$/i;
handler.admin = true;
handler.group = true;
handler.botAdmin = true;

export default handler;