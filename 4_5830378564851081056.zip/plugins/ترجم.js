// commands/ترجم.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - ترجمة النصوص 🌐

import axios from 'axios';
import { theme } from "../core/theme.js";

// قائمة اللغات المدعومة
const LANGUAGES = {
    'ar': 'العربية',
    'en': 'الإنجليزية',
    'fr': 'الفرنسية',
    'es': 'الإسبانية',
    'de': 'الألمانية',
    'it': 'الإيطالية',
    'pt': 'البرتغالية',
    'ru': 'الروسية',
    'zh': 'الصينية',
    'ja': 'اليابانية',
    'ko': 'الكورية',
    'tr': 'التركية',
    'fa': 'الفارسية',
    'ur': 'الأردية',
    'hi': 'الهندية'
};

let handler = async (m, { conn, text, usedPrefix, command }) => {

    // ━━━ لو مفيش نص ━━━
    if (!text) {
        const langList = Object.entries(LANGUAGES)
            .map(([code, name]) => `▸ ${code} : ${name}`)
            .join('\n');
        
        return conn.reply(m.chat, theme.build([
            { type: 'title', text: 'ترجمة النصوص 🌐' },
            { type: 'spacer' },
            { type: 'info', label: '📌', value: `الاستخدام: ${usedPrefix + command} [لغة] [النص]` },
            { type: 'spacer' },
            { type: 'info', label: '🌍 اللغات المتاحة', value: langList },
            { type: 'spacer' },
            { type: 'info', label: '📝 مثال', value: `${usedPrefix + command} en السلام عليكم` },
            { type: 'info', label: '📝 مثال2', value: `${usedPrefix + command} ar Hello world` }
        ]), m);
    }

    try {
        await m.react("⏳");

        // ━━━ استخراج اللغة والنص ━━━
        const parts = text.trim().split(/\s+/);
        let targetLang = parts[0]?.toLowerCase();
        let translateText = parts.slice(1).join(' ');

        // ━━━ لو اللغة غير موجودة، نعتبرها النص كله ونترجم للعربية ━━━
        if (!LANGUAGES[targetLang] || !translateText) {
            targetLang = 'ar';
            translateText = text;
        }

        // ━━━ طلب الترجمة ━━━
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=${encodeURIComponent(translateText)}`;
        const res = await axios.get(url, { timeout: 10000 });
        
        let translated = '';
        if (res.data && res.data[0]) {
            translated = res.data[0].map(item => item[0]).join('');
        }

        if (!translated) {
            throw new Error('فشلت الترجمة');
        }

        await m.react("✅");

        // ━━━ تحديد اللغة الأصلية ━━━
        let sourceLang = 'auto';
        if (res.data[2] && res.data[2] !== targetLang) {
            sourceLang = res.data[2];
        }

        const sourceLangName = LANGUAGES[sourceLang] || sourceLang;
        const targetLangName = LANGUAGES[targetLang];

        conn.reply(m.chat, theme.build([
            { type: 'title', text: 'نتيجة الترجمة 🌐' },
            { type: 'spacer' },
            { type: 'info', label: '📝 النص الأصلي', value: translateText.slice(0, 100) + (translateText.length > 100 ? '...' : '') },
            { type: 'info', label: `🔄 من ${sourceLangName} إلى ${targetLangName}`, value: '✓' },
            { type: 'divider' },
            { type: 'info', label: '📖 الترجمة', value: translated.slice(0, 500) + (translated.length > 500 ? '...' : '') },
            { type: 'spacer' },
            { type: 'info', label: '⚡', value: global.botName || 'PROTOTYPE' }
        ]), m);

    } catch (err) {
        await m.react("❌");
        console.error("Translation error:", err);
        
        conn.reply(m.chat, theme.build([
            { type: 'title', text: 'فشل الترجمة ❌' },
            { type: 'spacer' },
            { type: 'info', label: '⚠️', value: err.message || 'حدث خطأ أثناء الترجمة' },
            { type: 'spacer' },
            { type: 'info', label: '💡', value: 'تأكد من اتصال الإنترنت وجرب مرة أخرى' }
        ]), m);
    }
};

handler.help = ['ترجم [لغة] [نص]'];
handler.tags = ['tools'];
handler.command = /^(ترجم|ترجمة|translate)$/i;

export default handler;