/*
تـم الـتـنـسـيـق بـواسـطـة: ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ 💜
*/

import { generateWAMessageFromContent, proto, prepareWAMessageMedia } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';
import { theme } from '../core/theme.js';

let handler = async (m, { conn, usedPrefix, command }) => {
    const tips = [
        "قولنا أول أكلة جات في دماغك دلوقتي", 
        "ارسل صورة لآخر حاجة عجبتك على السوشيال ميديا",
        "هات صورة للمكان اللي إنت فيه دلوقتي",
        "قول 5 حاجات تحبهم بس من غير ترتيب",
        "صور حاجة لونها أصفر حواليك",
        "ارسل آخر محادثة في الواتساب",
        "قول أول 3 أرقام موبايل جات في بالك دلوقتي",
        "جيب صوتك وإنت بتغني كلمتين من أغنية بتحبها",
        "هات صورة لأغرب حاجة في بيتك",
        "ارسل صورة لحاجة قديمة عندك أكتر من 5 سنين",
        "هات فيديو مدته 10 ثواني من كاميرا موبايلك دلوقتي",
        "ارسل آخر ميم أو نكتة شفتها",
        "قول 3 حاجات نفسك تعملهم السنة دي",
        "جيب صورة لحد في الشغل أو الدراسة",
        "ارسل حاجة مضحكة حصلت لك النهاردة",
        "هات صورة للسماء دلوقتي",
        "ارسل آخر صورة للغروب عندك",
        "ارسل صوت لحد بتعمل فيه مقلب",
        "هات صورة لآخر حاجة أكلتها",
        "قول أول حاجة شربتها النهاردة",
        "ارسل صورة لكتاب بتقرأه دلوقتي",
        "قولنا آخر فيلم شوفته وعجبك",
        "هات صورة لحيوان بتحبه",
        "ارسل صورة للي بتعمله دلوقتي",
        "هات صورة لأول حاجة شفتها في الموبايل الصبح",
        "ارسل آخر صورة في معرض الصور بتاعك",
        "قولنا جملة مضحكة على السريع",
        "هات صورة لآخر مرة خرجت مع أصحابك",
        "ارسل صوت لحد بتزعق له فيه",
        "هات صورة للساعة دلوقتي",
        "قولنا حاجة جديدة تعلمتها النهاردة",
        "ارسل صورة للمكان اللي بتقعد فيه كتير",
        "هات صورة لمكان نفسك تزوره",
        "ارسل صورة لآخر مشروب شربته",
        "هات صورة لحد ليه تأثير كبير عليك",
        "قولنا حاجة ماحدش يعرفها عنك",
        "ارسل صورة لحاجة بتفكرك بطفولتك",
        "هات صوتك وإنت بتقرا أي جملة",
        "قولنا حاجة غريبة بتعملها لما تبقى لوحدك",
        "ارسل صورة لآخر حاجة اشتريتها",
        "هات صورة لشخص عزيز عليك",
        "قولنا آخر كتاب قرأته واستفدت منه",
        "ارسل صورة لآخر حاجة عجبتك وانت بتتفرج عليها",
        "هات صورة لأي حاجة شكلها غريب في موبايلك",
        "قول 3 حاجات بتحبهم في نفسك",
        "ارسل صوت لحد بتسلم عليه",
        "هات صورة لآخر حاجة ضحكتك",
        "ارسل صورة لأول حاجة جات في بالك لما صحيت"
    ];

    const randomChallenge = tips[Math.floor(Math.random() * tips.length)];

    try {
        // صورة افتراضية
        const imageUrl = 'https://telegra.ph/file/1aad4df0913a6e482fa34.jpg';
        const imageRes = await fetch(imageUrl);
        const imageBuffer = Buffer.from(await imageRes.arrayBuffer());
        const media = await prepareWAMessageMedia({ image: imageBuffer }, { upload: conn.waUploadToServer });

        const interactiveMessage = {
            body: proto.Message.InteractiveMessage.Body.create({
                text: theme.build([
                    { type: 'title', text: '🎮 خـلـيـك قـد الـتـحـدي' },
                    { type: 'spacer' },
                    { type: 'line', text: randomChallenge },
                    { type: 'divider' },
                    { type: 'line', text: '💡 اضغط على زر التالي لتحدي جديد' }
                ])
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
                text: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 🎮'
            }),
            header: proto.Message.InteractiveMessage.Header.create({
                title: '🎲 تحدي',
                hasMediaAttachment: true,
                imageMessage: media.imageMessage
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [{
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "🎲 تـحـدي جـديـد",
                        id: `${usedPrefix}تحدي`
                    })
                }]
            })
        };

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage
                }
            }
        }, { quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await conn.sendMessage(m.chat, { react: { text: '🎲', key: m.key } });

    } catch (error) {
        console.error('Error in challenge command:', error);
        await m.reply(theme.build([
            { type: 'error', text: '❌ حدث خطأ أثناء تشغيل التحدي' },
            { type: 'info', label: 'السبب', value: error.message || 'خطأ غير معروف' }
        ]));
    }
};

handler.help = ['تحدي'];
handler.tags = ['games'];
handler.command = /^(تحدي|حدي|تحدى)$/i;

export default handler;