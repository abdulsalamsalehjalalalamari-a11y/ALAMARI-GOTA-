import fs from 'fs'
import { join } from 'path'
import { tmpdir } from 'os'
import axios from 'axios'

// مفتاح API بتاعك (حط المفتاح اللي أنت بعته)
const GEMINI_API_KEY = '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'
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent'

let handler = async (m, { conn, usedPrefix, command }) => {
    const react = async (emoji) => {
        try { await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } }) } catch {}
    }

    if (!m.quoted) {
        await react('❌')
        return m.reply(`🜲⃝☠️ *تحليل الكود بالذكاء الاصطناعي* ☠️⃝🜲

👁️⃝🩸 *الاستخدام:*
• رد على رسالة فيها كود JavaScript
• اكتب: ${usedPrefix + command}

🤖 *المميزات:*
• تحليل ذكي للأخطاء
• اقتراحات للإصلاح
• شرح المشاكل بالعربية

𖤐⃝🩸 ${global.botName || '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2'}`)
    }

    let code = m.quoted.text || ''
    if (!code) {
        await react('❌')
        return m.reply(`🜲⃝☠️ *خطأ* ☠️⃝🜲
👁️⃝🩸 لا يوجد كود في الرسالة المقتبسة`)
    }

    // تنظيف الكود
    code = code.replace(/```js/g, '').replace(/```javascript/g, '').replace(/```/g, '').trim()

    if (code.length < 5) {
        await react('❌')
        return m.reply(`🜲⃝☠️ *خطأ* ☠️⃝🜲
👁️⃝🩸 الكود قصير جداً أو غير صالح`)
    }

    await react('🤖')
    await m.reply(`🜲⃝☠️ *جاري تحليل الكود بالذكاء الاصطناعي...* ☠️⃝🜲
👁️⃝🩸 ⏳ يرجى الانتظار...`)

    try {
        // تحليل الكود باستخدام Gemini AI
        const prompt = `أنت خبير في تحليل كود JavaScript. حلل الكود التالي وأخبرني:

1. هل يوجد أخطاء نحوية (Syntax Errors)؟ إذا وجد، اذكرها واشرحها.
2. هل يوجد أخطاء منطقية أو أخطاء محتملة أثناء التشغيل (Runtime Errors)؟
3. اقتراحات لتحسين الكود (إن وجدت).
4. شرح مبسط للكود.

الكود:
\`\`\`javascript
${code}
\`\`\`

أجب باللغة العربية، بشكل مختصر ومفيد.`

        const response = await axios.post(
            `${GEMINI_API_URL}?key=${GEMINI_API_KEY}`,
            {
                contents: [{
                    parts: [{ text: prompt }]
                }]
            },
            { timeout: 30000 }
        )

        const analysis = response.data?.candidates?.[0]?.content?.parts?.[0]?.text || 'لم يتم الحصول على تحليل'

        await react('✅')
        
        let resultMsg = `🜲⃝☠️ *تحليل الكود بالذكاء الاصطناعي* ☠️⃝🜲

👁️⃝🩸 *الكود المرسل:*
\`\`\`js
${code.length > 200 ? code.slice(0, 200) + '...' : code}
\`\`\`

🤖 *نتيجة التحليل:*
${analysis}

𖤐⃝🩸 ${global.botName || '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2'}`

        if (resultMsg.length > 4096) {
            resultMsg = resultMsg.slice(0, 4000) + '\n\n... (مقطع)'
        }

        await m.reply(resultMsg)

    } catch (err) {
        await react('❌')
        console.error('AI Error:', err)
        m.reply(`🜲⃝☠️ *خطأ في تحليل AI* ☠️⃝🜲
👁️⃝🩸 ${err.message || 'حدث خطأ أثناء الاتصال بالذكاء الاصطناعي'}
💡 جرب مرة أخرى أو تحقق من المفتاح

𖤐⃝🩸 ${global.botName || '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2'}`)
    }
}

handler.help = ['تحليل']
handler.tags = ['ai']
handler.command = /^(تحليل|ai|حلل|analyze)$/i

export default handler