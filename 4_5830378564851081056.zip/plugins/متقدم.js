// plugins/متقدم.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - رسائل Meta AI المتقدمة ✨

import { generateWAMessageFromContent, generateMessageIDV2 } from '@whiskeysockets/baileys';

let handler = async (m, { conn }) => {
    try {
        await conn.sendMessage(m.chat, { react: { text: '✨', key: m.key } });

        // 1. إعدادات الـ Meta
        const botMeta = {
            isForwarded: true,
            forwardingScore: 1,
            forwardedAiBotMessageInfo: { 
                botJid: "867051314767696@bot"
            },
            forwardOrigin: 4
        };

        // 2. جلب صورة البروفايل
        let imageUrl = 'https://i.imgur.com/8QKqSJp.jpeg';
        try {
            const botJid = conn.user.id.split(':')[0] + '@s.whatsapp.net';
            imageUrl = await conn.profilePictureUrl(botJid, 'image');
        } catch(e) {}

        // 3. بناء الهيكل الصحيح (مطابق للكود اللي شغال)
        const richMessage = {
            richResponseMessage: {
                messageType: 1,
                submessages: [
                    {
                        messageType: 2,
                        messageText: "\n✨ *⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - ميزات متقدمة* ✨\n",
                    },
                    {
                        messageType: 2,
                        messageText: "\n📊 *1- جدول الأوامر:*\n",
                    },
                    {
                        messageType: 4,
                        tableMetadata: {
                            title: "أوامر البوت",
                            rows: [
                                { items: ["الأمر", "الوصف", "مثال"], isHeading: true },
                                { items: [".menu", "القائمة الرئيسية", ".menu"], isHeading: false },
                                { items: [".مانهوا", "بحث عن مانهوا", ".مانهوا solo"], isHeading: false },
                                { items: [".جبتي", "الذكاء الاصطناعي", ".جبتي مرحبا"], isHeading: false },
                                { items: [".فيوز", "صناعة ملصقات", ".فيوز نص"], isHeading: false }
                            ]
                        }
                    },
                    {
                        messageType: 2,
                        messageText: "\n💻 *2- كود JavaScript:*\n",
                    },
                    {
                        messageType: 5,
                        codeMetadata: {
                            codeLanguage: "javascript",
                            codeBlocks: [
                                { highlightType: 2, codeContent: 'const bot = {' },
                                { highlightType: 3, codeContent: '    name: "PROTOTYPE",' },
                                { highlightType: 4, codeContent: '    version: "v2"' },
                                { highlightType: 1, codeContent: '};' }
                            ]
                        }
                    },
                    {
                        messageType: 2,
                        messageText: "\n🖼️ *3- صورة البوت:*\n",
                    },
                    {
                        messageType: 3,
                        imageMetadata: {
                            imageUrl: {
                                imagePreviewUrl: imageUrl,
                                imageHighResUrl: imageUrl,
                                sourceUrl: "https://wa.me/201002435496"
                            },
                            imageText: "صورة البوت",
                            alignment: 2,
                            tapLinkUrl: "https://wa.me/201002435496"
                        }
                    }
                ],
                contextInfo: botMeta
            }
        };

        // 4. إنشاء الرسالة بالهيكل الصحيح
        const msg = await generateWAMessageFromContent(m.chat, { 
            botForwardedMessage: { message: richMessage } 
        }, {
            senderId: conn.user.id,
            userJid: conn.user.id,
            messageId: generateMessageIDV2(conn.user.id)
        });

        // 5. إرسال الرسالة
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error("ERROR:", err);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        
        // رسالة بديلة إذا فشلت الطريقة المتقدمة
        await conn.sendMessage(m.chat, {
            text: "✨ *⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2*\n\n" +
                  "📊 *جدول الأوامر*\n" +
                  "┌─────────┬─────────────┐\n" +
                  "│ .menu   │ القائمة     │\n" +
                  "│ .مانهوا │ بحث        │\n" +
                  "│ .جبتي   │ الذكاء     │\n" +
                  "└─────────┴─────────────┘"
        }, { quoted: m });
    }
}

handler.help = ['متقدم'];
handler.tags = ['tools'];
handler.command = /^(متقدم|ميتا|meta|rich)$/i;

export default handler;