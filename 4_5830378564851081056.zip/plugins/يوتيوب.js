// commands/يوتيوب.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - تحميل فيديوهات وصوت من يوتيوب 🎬

import yts from 'yt-search';
import fetch from 'node-fetch';
import { exec } from 'child_process';
import { promisify } from 'util';
import { writeFileSync, unlinkSync, existsSync, readFileSync } from 'fs';
import { generateWAMessageFromContent, proto, prepareWAMessageMedia } from '@whiskeysockets/baileys';
import { theme } from '../core/theme.js';

const execAsync = promisify(exec);

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) {
        return m.reply(theme.build([
            { type: 'title', text: '🎬 يوتيوب' },
            { type: 'subtitle', text: 'تحميل فيديوهات وصوت من يوتيوب' },
            { type: 'divider' },
            { type: 'info', label: 'بحث', value: `${usedPrefix + command} اسم الفيديو` },
            { type: 'info', label: 'رابط', value: `${usedPrefix + command} https://youtu.be/xxx` }
        ]));
    }

    // ⭐ معالج اختيار الفيديو من نتائج البحث
    if (text.startsWith('select_')) {
        let parts = text.split('_');
        let searchId = parts[1];
        let index = parseInt(parts[2]);
        
        let results = global.ytSearchResults?.[searchId];
        if (!results || !results[index]) {
            return m.reply('❌ انتهت صلاحية البحث، يرجى إعادة البحث');
        }
        
        let selectedVideo = results[index];
        await showQualityOptions(m, conn, selectedVideo.url, usedPrefix, command);
        return;
    }
    
    // ⭐ معالج التحميل (vid_ أو aud_)
    if (text.startsWith('vid_') || text.startsWith('aud_')) {
        let parts = text.split('_');
        let type = parts[0];
        let quality = parts[1];
        let url = parts.slice(2).join('_');
        
        await m.react('⏳');
        
        try {
            let videoInfo = await getVideoInfo(url);
            if (!videoInfo?.api?.status === 'ok') throw new Error('فشل جلب الفيديو');
            
            if (type === 'aud') {
                // ✅ طريقة تحويل الفيديو إلى صوت
                await conn.sendMessage(m.chat, { text: `⏳ جاري تحميل الفيديو لاستخراج الصوت...` });
                
                // اختيار فيديو بجودة منخفضة (لتوفير الوقت)
                let videoItem = videoInfo.api.mediaItems.find(i => i.type === 'Video' && i.mediaRes === '256x144');
                if (!videoItem) {
                    videoItem = videoInfo.api.mediaItems.find(i => i.type === 'Video');
                }
                
                if (!videoItem) throw new Error('لا توجد جودة فيديو متاحة');
                
                let videoUrl = await getDownloadUrl(videoItem.mediaUrl);
                if (!videoUrl) throw new Error('فشل الحصول على رابط الفيديو');
                
                // تحميل الفيديو
                let videoRes = await fetch(videoUrl);
                let videoBuffer = await videoRes.buffer();
                
                await conn.sendMessage(m.chat, { text: `🎬 تم التحميل، جاري استخراج الصوت...` });
                
                // استخراج الصوت
                let inputPath = `./tmp/video_${Date.now()}.mp4`;
                let outputPath = `./tmp/audio_${Date.now()}.mp3`;
                
                writeFileSync(inputPath, videoBuffer);
                await execAsync(`ffmpeg -i "${inputPath}" -vn -acodec libmp3lame -b:a 128k "${outputPath}" -y`);
                
                let audioBuffer = readFileSync(outputPath);
                
                // تنظيف الملفات المؤقتة
                if (existsSync(inputPath)) unlinkSync(inputPath);
                if (existsSync(outputPath)) unlinkSync(outputPath);
                
                await conn.sendMessage(m.chat, {
                    audio: audioBuffer,
                    mimetype: 'audio/mpeg',
                    fileName: `${videoInfo.api.title}.mp3`,
                    ptt: false,
                    caption: theme.build([
                        { type: 'title', text: '🎵 صـوت يـوتـيـوب' },
                        { type: 'info', label: 'العنوان', value: videoInfo.api.title.substring(0, 40) }
                    ])
                });
                
                await m.react('✅');
                
            } else {
                // ✅ تحميل فيديو مباشر
                let mediaItem = null;
                switch(quality) {
                    case '1080': mediaItem = videoInfo.api.mediaItems.find(i => i.type === 'Video' && i.mediaQuality === 'FHD'); break;
                    case '720': mediaItem = videoInfo.api.mediaItems.find(i => i.type === 'Video' && i.mediaQuality === 'HD'); break;
                    case '480': mediaItem = videoInfo.api.mediaItems.find(i => i.type === 'Video' && i.mediaRes === '854x480'); break;
                    case '360': mediaItem = videoInfo.api.mediaItems.find(i => i.type === 'Video' && i.mediaRes === '640x360'); break;
                    default: mediaItem = videoInfo.api.mediaItems.find(i => i.type === 'Video');
                }
                
                if (!mediaItem) throw new Error(`جودة ${quality} غير متوفرة`);
                
                await conn.sendMessage(m.chat, { text: `⏳ جاري تحميل الفيديو... (${mediaItem.mediaFileSize || 'جاري الحساب'})` });
                
                let finalUrl = await getDownloadUrl(mediaItem.mediaUrl);
                if (!finalUrl) throw new Error('فشل الحصول على رابط التحميل');
                
                await conn.sendMessage(m.chat, {
                    video: { url: finalUrl },
                    caption: `🎬 *${videoInfo.api.title}*\n🎚️ الجودة: ${quality}p`
                });
                
                await m.react('✅');
            }
            
        } catch (error) {
            console.error(error);
            await m.react('❌');
            m.reply(`❌ فشل التحميل: ${error.message}`);
        }
        return;
    }
    
    // ⭐ معالج الرابط المباشر
    if (text.includes('youtu.be') || text.includes('youtube.com')) {
        await showQualityOptions(m, conn, text, usedPrefix, command);
        return;
    }
    
    // ⭐ معالج البحث
    await m.react('⏳');
    
    try {
        let searchResults = await yts(text);
        let videos = searchResults.videos.slice(0, 6);
        
        if (!videos || videos.length === 0) {
            await m.react('❌');
            return m.reply(theme.build([
                { type: 'title', text: '❌ لا توجد نتائج' },
                { type: 'error', text: `للبحث: ${text}` }
            ]));
        }
        
        global.ytSearchResults = global.ytSearchResults || {};
        let searchId = Date.now();
        global.ytSearchResults[searchId] = videos;
        setTimeout(() => delete global.ytSearchResults[searchId], 60000);
        
        let imgMsg = null;
        try {
            imgMsg = await prepareWAMessageMedia(
                { image: { url: videos[0].thumbnail } },
                { upload: conn.waUploadToServer }
            );
        } catch {}
        
        let rows = [];
        for (let i = 0; i < videos.length; i++) {
            let v = videos[i];
            rows.push({
                title: `${i+1}. ${v.title.substring(0, 45)}`,
                description: `📺 ${v.author?.name || 'غير معروف'} | ⏱️ ${v.timestamp}`,
                id: `${usedPrefix}${command} select_${searchId}_${i}`
            });
        }
        
        const interactiveMessage = {
            body: { text: `🔍 *نتائج البحث عن:* ${text}\n\n📋 اختر الفيديو من القائمة:` },
            footer: { text: `⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2` },
            header: {
                hasMediaAttachment: !!imgMsg?.imageMessage,
                imageMessage: imgMsg?.imageMessage || null
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: 'single_select',
                        buttonParamsJson: JSON.stringify({
                            title: "🎬 نتائج البحث",
                            sections: [{ title: "📹 اختر الفيديو", rows }]
                        })
                    }
                ],
                messageParamsJson: ""
            }
        };
        
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: { message: { interactiveMessage } }
        }, { userJid: conn.user.jid, quoted: m });
        
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await m.react('✅');
        
    } catch (error) {
        console.error(error);
        await m.react('❌');
        m.reply(`❌ خطأ في البحث: ${error.message}`);
    }
};

// ═══════════════════════════════════════════════════════════════
// دوال مساعدة
// ═══════════════════════════════════════════════════════════════

async function showQualityOptions(m, conn, url, usedPrefix, command) {
    await m.react('⏳');
    
    try {
        let videoInfo = await getVideoInfo(url);
        if (!videoInfo?.api?.status === 'ok') throw new Error('فشل جلب معلومات الفيديو');
        
        let data = videoInfo.api;
        
        let imgMsg = null;
        try {
            imgMsg = await prepareWAMessageMedia(
                { image: { url: data.imagePreviewUrl } },
                { upload: conn.waUploadToServer }
            );
        } catch {}
        
        let caption = `🎬 *${data.title.substring(0, 50)}*\n\n📺 ${data.userInfo.name}\n⏱️ ${data.mediaStats.mediaCount || 'غير معروف'}\n\n🎚️ *اختر جودة التحميل:*`;
        
        let videoRows = [
            { title: "🎬 1080p FHD", description: "جودة عالية جداً", id: `${usedPrefix}${command} vid_1080_${url}` },
            { title: "🎬 720p HD", description: "جودة عالية", id: `${usedPrefix}${command} vid_720_${url}` },
            { title: "🎬 480p SD", description: "جودة متوسطة", id: `${usedPrefix}${command} vid_480_${url}` },
            { title: "🎬 360p", description: "جودة منخفضة", id: `${usedPrefix}${command} vid_360_${url}` }
        ];
        
        let audioRows = [
            { title: "🎵 MP3 (جودة عالية)", description: "يتم استخراج الصوت من الفيديو", id: `${usedPrefix}${command} aud_128_${url}` }
        ];
        
        const interactiveMessage = {
            body: { text: caption },
            footer: { text: `⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2` },
            header: {
                hasMediaAttachment: !!imgMsg?.imageMessage,
                imageMessage: imgMsg?.imageMessage || null
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: 'single_select',
                        buttonParamsJson: JSON.stringify({
                            title: "🎬 فيديو",
                            sections: [{ title: "📹 جودات الفيديو", rows: videoRows }]
                        })
                    },
                    {
                        name: 'single_select',
                        buttonParamsJson: JSON.stringify({
                            title: "🎵 صوت",
                            sections: [{ title: "🎧 تحميل كصوت MP3", rows: audioRows }]
                        })
                    }
                ],
                messageParamsJson: ""
            }
        };
        
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: { message: { interactiveMessage } }
        }, { userJid: conn.user.jid, quoted: m });
        
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await m.react('✅');
        
    } catch (error) {
        console.error(error);
        m.reply(`❌ خطأ: ${error.message}`);
        await m.react('❌');
    }
}

async function getVideoInfo(url) {
    let res = await fetch('https://app.ytdown.to/proxy.php', {
        method: 'POST',
        headers: { 
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Mozilla/5.0'
        },
        body: `url=${encodeURIComponent(url)}`
    });
    let text = await res.text();
    return JSON.parse(text.replace(/^\uFEFF/, ''));
}

async function getDownloadUrl(videoUrl, maxAttempts = 20, delayMs = 3000) {
    for (let i = 0; i < maxAttempts; i++) {
        let res = await fetch('https://app.ytdown.to/proxy.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `url=${encodeURIComponent(videoUrl)}`
        });
        let data = await res.json();
        if (data.api.status === 'completed' && data.api.fileUrl) return data.api.fileUrl;
        await new Promise(r => setTimeout(r, delayMs));
    }
    return null;
}

handler.help = ['يوتيوب'];
handler.tags = ['downloader'];
handler.command = /^(يوتيوب|بحث|تحميل|ytdl)$/i;

export default handler;