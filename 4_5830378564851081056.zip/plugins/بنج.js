// plugins/ping.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - قياس سرعة البوت ⚡

import { performance } from 'perf_hooks';
import { theme } from '../core/theme.js';

let handler = async (m, { conn }) => {
    
    await conn.sendMessage(m.chat, { react: { text: '⚡', key: m.key } });
    
    // حساب الوقت المستغرق
    let old = performance.now();
    let neww = performance.now();
    let speed = (neww - old).toFixed(2);
    
    // حساب سرعة الاتصال بالواتساب
    let start = Date.now();
    await conn.sendMessage(m.chat, { text: '...' });
    let end = Date.now();
    let whatsappSpeed = end - start;
    
    await conn.reply(m.chat, theme.build([
        { type: 'title', text: '⚡ قـيـاس سـرعـة الـبـوت' },
        { type: 'divider' },
        { type: 'info', label: '🚀 سـرعـة الـبـوت', value: `${speed} ms` },
        { type: 'info', label: '📡 سـرعـة الـواتـسـاب', value: `${whatsappSpeed} ms` },
        { type: 'divider' },
        { type: 'line', text: `🟢 البوت يعمل بسرعة ${speed < 50 ? 'ممتازة' : speed < 150 ? 'جيدة' : 'بطيئة'}` }
    ]), m);
};

handler.help = ['قيس'];
handler.tags = ['tools'];
handler.command = /^(قيس|سرعة|بنج|ping|speed)$/i;

export default handler;