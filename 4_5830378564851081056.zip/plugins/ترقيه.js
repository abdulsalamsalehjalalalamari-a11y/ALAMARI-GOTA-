// plugins/admin.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - ترقية أو إعفاء عضو (بالرد فقط) 👑

import { theme } from '../core/theme.js';
import { sticker } from '../Z/sticker.js';
import fetch from 'node-fetch';

let handler = async (m, { conn, usedPrefix, command, isAdmin, isOwner }) => {
    
    // التحقق من صلاحيات المشرف
    if (!isAdmin && !isOwner) {
        return m.reply(theme.build([
            { type: 'error', text: '⚠️ هذا الأمر مخصص للمشرفين فقط' }
        ]));
    }

    // طريقة الحصول على المستخدم (فقط بالرد على الرسالة)
    let user = null;
    
    if (m.quoted && m.quoted.sender) {
        user = m.quoted.sender;
    } else {
        await conn.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
        return m.reply(theme.build([
            { type: 'title', text: '👑 إدارة المشرفين' },
            { type: 'spacer' },
            { type: 'warning', text: '⚠️ قم بالرد على رسالة الشخص أولاً' },
            { type: 'info', label: 'لترقية عضو', value: `• رد على رسالة العضو\n• ثم اكتب ${usedPrefix + command}` },
            { type: 'info', label: 'لإعفاء عضو', value: `• رد على رسالة العضو\n• ثم اكتب ${usedPrefix}اعفاء` }
        ]));
    }

    // تنظيف الـ JID
    user = user.split('@')[0] + '@s.whatsapp.net';

    try {
        // ترقية عضو
        if (command.match(/^(ترقيه|رفع|ارفع|promote)$/i)) {
            await conn.groupParticipantsUpdate(m.chat, [user], 'promote');
            
            // رابط صورة الطاغية
            const imageUrl = 'https://file.garden/aauvg01sjleV_ic1/IMG-20260529-WA0354.jpg';
            
            // تحميل الصورة وتحويلها إلى ملصق
            const imgRes = await fetch(imageUrl);
            const imgBuffer = await imgRes.buffer();
            
            // إنشاء الملصق
            let stiker = await sticker(imgBuffer, null, 'مبروك اصبحت طاغية 🐦', '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2');
            
            // إرسال الملصق
            await conn.sendMessage(m.chat, { sticker: stiker }, { quoted: m });
            
            // رسالة نصية تأكيدية
            const successMsg = theme.build([
                { type: 'title', text: '🎉 مـبـروك' },
                { type: 'spacer' },
                { type: 'info', label: '👑 العضو', value: `@${user.split('@')[0]}` },
                { type: 'line', text: 'اصـبـحـت طـاغـيـة 🐦' }
            ]);
            
            await conn.sendMessage(m.chat, { text: successMsg, mentions: [user] }, { quoted: m });
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        }
        
        // إعفاء عضو
        else if (command.match(/^(اعفاء|تنزيل|demote)$/i)) {
            await conn.groupParticipantsUpdate(m.chat, [user], 'demote');
            
            const successMsg = theme.build([
                { type: 'title', text: '📉 تم الإعفاء' },
                { type: 'spacer' },
                { type: 'info', label: '👑 العضو', value: `@${user.split('@')[0]}` },
                { type: 'line', text: 'تم إعفاء العضو من الإدارة' }
            ]);
            
            await conn.sendMessage(m.chat, { text: successMsg, mentions: [user] }, { quoted: m });
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        }
        
    } catch (e) {
        console.error(e);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        m.reply(theme.build([
            { type: 'error', text: '❌ فشل تنفيذ العملية' },
            { type: 'info', label: 'السبب', value: e.message?.slice(0, 100) || 'خطأ غير معروف' }
        ]));
    }
};

handler.help = ['ترقيه', 'اعفاء'];
handler.tags = ['group'];
handler.command = /^(ترقيه|رع|ارفع|promote|اعفاء|تنزيل|demote)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;