// plugins/zawgny.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - أمر زوجني (اقتراح زواج عشوائي) 💍👰🤵

import fetch from 'node-fetch';
import { theme } from '../core/theme.js';

let toM = a => '@' + a.split('@')[0];

let handler = async (m, { conn, groupMetadata }) => {
    try {
        // التأكد من وجود المجموعة
        if (!groupMetadata) {
            return m.reply(theme.build([
                { type: 'error', text: '❌ هذا الأمر يعمل فقط في المجموعات' }
            ]));
        }

        // الحصول على قائمة الأعضاء
        let ps = groupMetadata.participants.map(v => v.id);
        
        if (ps.length < 2) {
            return m.reply(theme.build([
                { type: 'error', text: '❌ المجموعة تحتاج إلى عضوين على الأقل للزواج' }
            ]));
        }
        
        // اختيار عريس عشوائي
        let a = ps[Math.floor(Math.random() * ps.length)];
        
        // اختيار عروس عشوائي مختلف عن العريس
        let b;
        do {
            b = ps[Math.floor(Math.random() * ps.length)];
        } while (b === a);

        // رابط الصورة (لحفل الزواج)
        const imageUrl = 'https://telegra.ph/file/0dde86d97f9cab0ea3ccb.jpg';
        
        // تحميل الصورة
        const imageRes = await fetch(imageUrl);
        const imageBuffer = Buffer.from(await imageRes.arrayBuffer());

        // إرسال الصورة مع رسالة الزواج
        await conn.sendMessage(m.chat, {
            image: imageBuffer,
            caption: theme.build([
                { type: 'title', text: '💍 اعــلان زواج 💍' },
                { type: 'spacer' },
                { type: 'info', label: '👨‍💼 الـعـريـس', value: toM(a) },
                { type: 'info', label: '👩‍💼 الـعـروس', value: toM(b) },
                { type: 'divider' },
                { type: 'line', text: '🎉 الف مبروك 🎉' },
                { type: 'line', text: '😂 كل واحد يوزع حلويات ويشيل معاه البوفيه' }
            ]),
            mentions: [a, b]
        }, { quoted: m });
        
        await conn.sendMessage(m.chat, { react: { text: '💍', key: m.key } });

    } catch (err) {
        console.error('زوجني error:', err);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await m.reply(theme.build([
            { type: 'error', text: '❌ حدث خطأ' },
            { type: 'info', label: 'السبب', value: err.message || 'خطأ غير معروف' }
        ]));
    }
};

handler.help = ['زوجني'];
handler.tags = ['entertainment'];
handler.command = /^(زوجني|زواج|تزوج)$/i;
handler.group = true;

export default handler;