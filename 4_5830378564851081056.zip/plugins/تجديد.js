// امر تجديد رابط المجموعة - إعادة إنشاء رابط دعوة جديد

import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';

let handler = async (m, { conn, isAdmin, isBotAdmin }) => {
  // التحقق من صلاحيات المستخدم
  if (!isAdmin) {
    return global.dfail('admin', m, conn)
  }

  // التحقق من صلاحيات البوت
  if (!isBotAdmin) {
    return global.dfail('botAdmin', m, conn)
  }

  try {
    const groupId = m.chat;

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    // تجديد رابط الدعوة
    const newInviteCode = await conn.groupRevokeInvite(groupId);
    const newLink = `https://chat.whatsapp.com/${newInviteCode}`;

    // الحصول على صورة المجموعة (أو استخدام صورة افتراضية)
    let groupImage;
    try {
      groupImage = await conn.profilePictureUrl(groupId, 'image');
    } catch (e) {
      groupImage = 'https://file.garden/aauvg01sjleV_ic1/2b676b830f863f489572f163466adb97.jpg';
    }

    // تجهيز الصورة للإرسال
    const media = await prepareWAMessageMedia(
      { image: { url: groupImage } },
      { upload: conn.waUploadToServer }
    );

    const teks = `> ꒦꒷𓆩🔄𓆪꒷꒦
> 
> 🜲⃝☠️ *تـم تـجـديـد رابـط الـدعـوَة*
> 👁️⃝🩸 *الرابط الجديد:* ${newLink}
> 
> ꒦꒷𓆩☣️𓆪꒷꒦ ✧ 🩸 𖤐 🜲 ✧ ꒦꒷𓆩☣️𓆪꒷꒦
> 
> 𓆩⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 𓆪`;

    // إنشاء الرسالة التفاعلية مع الزر
    const msg = generateWAMessageFromContent(groupId, {
      viewOnceMessage: {
        message: {
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: { text: teks.trim() },
            footer: { text: `PROTOTYPE-MD` },
            header: {
              hasMediaAttachment: true,
              imageMessage: media.imageMessage,
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "cta_copy",
                  buttonParamsJson: JSON.stringify({
                    display_text: '📋 نسخ الرابط',
                    copy_code: newLink
                  })
                }
              ],
              messageParamsJson: ""
            }
          })
        }
      }
    }, { quoted: m });

    await conn.relayMessage(groupId, msg.message, { messageId: msg.key.id });
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (err) {
    console.error(err);
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    m.reply(`❌ *حدث خطأ أثناء تجديد الرابط*`);
  }
};

handler.help = ['تجديد_الرابط'];
handler.tags = ['group'];
handler.command = /^(تجديد|تحديث_الرابط|newlink)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;