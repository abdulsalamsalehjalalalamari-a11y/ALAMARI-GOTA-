// plugins/q7-ai.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - قسم الذكاء 🤖

import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';
import { theme } from '../core/theme.js';

let handler = async (m, { conn, usedPrefix: _p }) => {
  try {
    const user = await conn.getName(m.sender);
    const fecha = new Date().toLocaleDateString('ar-SA', { 
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' 
    });
    const hora = new Date().toLocaleTimeString('ar-SA');
    
    let old = performance.now();
    let neww = performance.now();
    let speed = (neww - old).toFixed(4);

    let menuText = `*│* ✍️⃝🌿 *الـاسـم:* ${user}\n`
    menuText += `*│* 📱⃝🌿 *الـرقـم:* ${m.sender.split('@')[0]}\n`
    menuText += `*│* ⚡⃝🌿 *الـبـيـنـج:* ${speed}ms\n`
    menuText += `*│* 📅⃝🌿 *الـتـاريـخ:* ${fecha}\n`
    menuText += `*│* ⏰⃝🌿 *الـوقـت:* ${hora}\n`
    menuText += `*╰━━━━━━━━━━━━━⃝💙*\n\n` // Changed heart to blue
    
    menuText += ` ִᗀᩙᰰ ̼𝆬💙̸〫 ᮭ࣪࣪ ⸼۫  𝑨𝑰 𝑩𝑶𝑻 𝅄 ۫ ִᗀᩙᰰ ̼𝆬💙\n\n` // Changed to blue hearts
    
    menuText += `*╭━━ 𝐀𝐈 𝐌𝐄𝐍𝐔 ━━⃝💙*\n` // Changed to blue
    menuText += `*│* *『 ❐╎ جبتي ⃝💙 』*\n`
    menuText += `*│* *『 ❐╎ كابلود ⃝💙 』*\n`
    menuText += `*│* *『 ❐╎ كلود ⃝💙 』*\n`
    menuText += `*│* *『 ❐╎ ai ⃝💙 』*\n`
    menuText += `*│* *『 ❐╎ توليد ⃝💙 』*\n`
    menuText += `*╰━━━━━━━━━━━━━⃝💙*\n\n` // Changed to blue

    await conn.sendMessage(m.chat, { react: { text: '🤖', key: m.key } });

    // 🔥 الصورة الجديدة لقسم الذكاء (زرقاء)
    const imageUrl = 'https://file.garden/aauvg01sjleV_ic1/6ad1b78d7ce544f28deae744ba9c066a.png';
    const imageRes = await fetch(imageUrl);
    const imageBuffer = Buffer.from(await imageRes.arrayBuffer());
    const media = await prepareWAMessageMedia({ image: imageBuffer }, { upload: conn.waUploadToServer });
    
    const nativeFlowPayload = {
      body: { text: menuText },
      footer: { text: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 🤖' },
      header: {
        hasMediaAttachment: true,
        subtitle: '🤖 قـسـم الـذكـاء',
        imageMessage: media.imageMessage
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '🔙 الـعـودة للـقـائـمـة',
              id: '.الاوامر'
            })
          },
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: '👑 الـمـطـور',
              id: '.المطور'
            })
          }
        ],
        messageParamsJson: JSON.stringify({
          bottom_sheet: {
            in_thread_buttons_limit: 1,
            list_title: "🤖 قـسـم الـذكـاء",
            button_title: "خـيـارات"
          }
        })
      }
    };

    const interactiveMessage = proto.Message.InteractiveMessage.fromObject(nativeFlowPayload);
    const fkontak = await makeFkontak();
    const msg = generateWAMessageFromContent(m.chat, { interactiveMessage }, { 
      userJid: conn.user.jid, 
      quoted: fkontak 
    });
    
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

  } catch (e) {
    console.error(e);
    await conn.sendMessage(m.chat, { 
      text: theme.build([
        { type: 'title', text: 'خـطـأ' },
        { type: 'subtitle', text: 'حدث خطأ في تحميل قسم الذكاء' }
      ])
    }, { quoted: m });
  }
}

async function makeFkontak() {
  try {
    const res = await fetch('https://file.garden/aauvg01sjleV_ic1/a2075690da240b4d4af5e9affed48bbe.jpg');
    const thumb2 = Buffer.from(await res.arrayBuffer());
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2', jpegThumbnail: thumb2 } },
      participant: '0@s.whatsapp.net'
    };
  } catch {
    return undefined;
  }
}

handler.help = ['ق7'];
handler.tags = ['main'];
handler.command = ['ق7', 'الذكاء', 'ai'];

export default handler;