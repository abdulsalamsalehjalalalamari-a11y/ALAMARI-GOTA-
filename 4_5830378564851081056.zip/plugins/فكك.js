// plugins/game-unscramble.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - لعبة فك الكلمة 🔤

import fs from "fs";
import { theme } from '../core/theme.js';

let timeout = 60000;
let poin = 500;

let handler = async (m, { conn }) => {

    conn.tekateki = conn.tekateki || {};
    let id = m.chat;

    // التحقق من وجود لعبة نشطة
    if (id in conn.tekateki) {
        await m.react("⏳");
        return conn.reply(m.chat, theme.build([
            { type: 'title', text: '⚠️ تـنـبـيـه' },
            { type: 'subtitle', text: 'هناك سؤال قائم بالفعل، انتظر انتهاء الجولة!' }
        ]), m);
    }

    // التحقق من وجود ملف الأسئلة
    if (!fs.existsSync("./src/game/فكك.json")) {
        return m.reply(theme.build([
            { type: 'title', text: 'خـطـأ' },
            { type: 'subtitle', text: 'ملف الأسئلة غير موجود!' }
        ]));
    }

    let tekateki = JSON.parse(fs.readFileSync("./src/game/فكك.json"));
    let json = tekateki[Math.floor(Math.random() * tekateki.length)];

    let caption = `> ${theme.divider}
>
> 🜲⃝☠️ *لـعـبـة "فـكـك الـكـلـمـة"* 🔤
> 𖤐⃝🩸 *${json.question}*
>
> ${theme.smallDivider}
>
> 👁️⃝🩸 *الـوقـت:* ${(timeout / 1000).toFixed(0)} ثانية
> ☣️⃝🩸 *الـجـائـزة:* ${poin} نقطة
> 𖤐⃝🩸 *الـلاعـب:* @${m.sender.split("@")[0]}
>
> ${theme.smallDivider}
>
> ✍️⃝🩸 *أرسـل الإجـابـة الـآن!*
>
> ${theme.endDivider}`;

    let sent = await conn.reply(m.chat, caption, m, { mentions: [m.sender] });

    conn.tekateki[id] = [
        sent,
        json,
        poin,
        setTimeout(async () => {
            if (conn.tekateki[id]) {
                await conn.reply(m.chat, theme.build([
                    { type: 'title', text: '⏰ انـتـهـى الـوقـت' },
                    { type: 'subtitle', text: `الإجابة الصحيحة هي: ${json.response}` }
                ]), sent);
                delete conn.tekateki[id];
            }
        }, timeout)
    ];

    await m.react("✍️");
};

// 🔥 معالج الإجابات
handler.before = async (m, { conn }) => {
    let id = m.chat;
    if (!conn.tekateki || !conn.tekateki[id]) return false;
    if (!m.text) return false;
    
    let game = conn.tekateki[id];
    let json = game[1];
    let poin = game[2];
    
    // مقارنة الإجابة
    let userAnswer = m.text.trim().toLowerCase();
    let correctAnswer = json.response.toLowerCase();
    
    if (userAnswer === correctAnswer || userAnswer.includes(correctAnswer) || correctAnswer.includes(userAnswer)) {
        
        // إضافة نقاط
        if (!global.db.data.users[m.sender].points) {
            global.db.data.users[m.sender].points = 0;
        }
        global.db.data.users[m.sender].points += poin;
        
        await conn.reply(m.chat, theme.build([
            { type: 'title', text: '✅ إجـابـة صـحـيـحـة' },
            { type: 'subtitle', text: `🎉 أحسنت! +${poin} نقطة` },
            { type: 'divider' },
            { type: 'info', label: 'الإجابة', value: json.response },
            { type: 'info', label: 'نقاطك', value: `${global.db.data.users[m.sender].points} نقطة` }
        ]), m);
        
        clearTimeout(game[3]);
        delete conn.tekateki[id];
        return true;
    }
    
    return false;
};

handler.help = ["فكك"];
handler.tags = ["game"];
handler.command = /^(فكك)$/i;

export default handler;