// plugins/lakabi.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 - عرض اللقب الخاص بي 👥

let handler = async (m, { conn }) => {
    try {
        const groupId = m.chat;
        
        // التأكد من وجود قاعدة البيانات
        if (!global.db?.data?.users) {
            return m.reply(`❌ قاعدة البيانات غير جاهزة`);
        }
        
        const users = global.db.data.users;
        const user = users[m.sender];

        if (!user || !user.groups || !user.groups[groupId] || !user.groups[groupId].name) {
            return m.reply(`❌ أنت غير مسجل في هذه المجموعة.\nاستخدم .حجز_لقب لتسجيل لقبك`);
        }

        const nickname = user.groups[groupId].name;
        
        let msg = `╭━━ 👥 *لقبي* ━━⃝💙
│
│ 🏷️ *لقبك:* ${nickname}
│ 👤 *بواسطة:* ${m.pushName || m.sender.split('@')[0]}
│
╰━━━━━━━━━━━━━⃝💙`;

        await conn.sendMessage(m.chat, { text: msg }, { quoted: m });

    } catch (err) {
        console.error('لقبي error:', err);
        await m.reply(`❌ حدث خطأ: ${err.message || err}`);
    }
};

handler.help = ['لقبي'];
handler.tags = ['unions'];
handler.command = /^(لقبي|mynickname|nick)$/i;
handler.group = true;

export default handler;