// plugins/fun-stats.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - أوامر التسلية (نسب) 🎭

import { theme } from '../core/theme.js';

let handler = async (m, { conn, command, text, usedPrefix }) => {

  const rand = (max) => Math.floor(Math.random() * (max + 1));

  // تحديد الاسم المستهدف
  let targetName = '';
  
  // حالة 1: منشن
  if (m.mentionedJid && m.mentionedJid[0]) {
    try {
      targetName = await conn.getName(m.mentionedJid[0]);
    } catch {
      targetName = m.mentionedJid[0].split('@')[0];
    }
  }
  // حالة 2: رد على رسالة
  else if (m.quoted && m.quoted.sender) {
    try {
      targetName = await conn.getName(m.quoted.sender);
    } catch {
      targetName = m.quoted.sender.split('@')[0];
    }
  }
  // حالة 3: كتابة اسم مباشر
  else if (text && text.trim()) {
    targetName = text.trim();
  }
  // حالة 4: لا يوجد هدف
  else {
    return m.reply(theme.build([
      { type: 'title', text: `🎭 أمر ${command}` },
      { type: 'spacer' },
      { type: 'warning', text: 'قم بمنشن الشخص أو كتابة اسمه أو رد على رسالته' },
      { type: 'info', label: 'مثال', value: `${usedPrefix + command} @user` },
      { type: 'info', label: 'مثال', value: `${usedPrefix + command} محمد` }
    ]));
  }

  // التأكد من وجود اسم
  if (!targetName) {
    targetName = 'المستخدم';
  }

  const displayText = targetName.toUpperCase();
  const randomPercent = rand(100);

  let reply = '';
  let emoji = '';

  switch (command) {
    case 'ورع':
      emoji = '🧒';
      reply = `╭━━ 🎭 *نسبة الورع* ━━⃝💜
│
│ 👤 *الاسم:* ${displayText}
│ 📊 *النسبة:* ${randomPercent}%
│ 💬 *التعليق:* ${randomPercent > 70 ? 'يا سلام ورع بمعنى الكلمة 😂' : 'لسه صغير واعد 🧒'}
│
╰━━━━━━━━━━━━━⃝💜`;
      break;
      
    case 'اهبل':
      emoji = '🤪';
      reply = `╭━━ 🎭 *نسبة الهبل* ━━⃝💜
│
│ 👤 *الاسم:* ${displayText}
│ 📊 *النسبة:* ${randomPercent}%
│ 💬 *التعليق:* ${randomPercent > 70 ? 'اهبل بطل خلي بالك منه 😂' : 'لسه شاطر وواعي 🧠'}
│
╰━━━━━━━━━━━━━⃝💜`;
      break;
      
    case 'خروف':
      emoji = '🐑';
      reply = `╭━━ 🎭 *نسبة الخرفنة* ━━⃝💜
│
│ 👤 *الاسم:* ${displayText}
│ 📊 *النسبة:* ${randomPercent}%
│ 💬 *التعليق:* ${randomPercent > 70 ? 'خروف والله يابو حمل 🐑' : 'لسه مش خروف كفاية 😅'}
│
╰━━━━━━━━━━━━━⃝💜`;
      break;
      
    case 'جميل':
      emoji = '😍';
      reply = `╭━━ 🎭 *نسبة الجمال* ━━⃝💜
│
│ 👤 *الاسم:* ${displayText}
│ 📊 *النسبة:* ${randomPercent}%
│ 💬 *التعليق:* ${randomPercent > 70 ? 'فديت القمر 🌙' : 'جمالك جايب آخره ✨'}
│
╰━━━━━━━━━━━━━⃝💜`;
      break;
      
    case 'ذكاء':
      emoji = '🧠';
      reply = `╭━━ 🎭 *نسبة الذكاء* ━━⃝💜
│
│ 👤 *الاسم:* ${displayText}
│ 📊 *النسبة:* ${randomPercent}%
│ 💬 *التعليق:* ${randomPercent > 70 ? 'عبقري بمعنى الكلمة 🧠' : 'ذكائك في ازدياد 📈'}
│
╰━━━━━━━━━━━━━⃝💜`;
      break;
      
    case 'غباء':
      emoji = '🤦';
      reply = `╭━━ 🎭 *نسبة الغباء* ━━⃝💜
│
│ 👤 *الاسم:* ${displayText}
│ 📊 *النسبة:* ${randomPercent}%
│ 💬 *التعليق:* ${randomPercent > 70 ? 'غبي بطل خلي بالك 🤦' : 'لسه فيه أمل 🤞'}
│
╰━━━━━━━━━━━━━⃝💜`;
      break;
      
    default:
      reply = theme.build([
        { type: 'error', text: `الأمر ${command} غير معروف` }
      ]);
  }

  await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } });
  return m.reply(reply);
};

handler.help = ['ورع', 'اهبل', 'خروف', 'جميل', 'ذكاء', 'غباء'];
handler.tags = ['entertainment'];
handler.command = /^(ورع|اهبل|خروف|جميل|ذكاء|غباء)$/i;

export default handler;