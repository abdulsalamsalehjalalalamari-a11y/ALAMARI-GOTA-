// commands/لفيديو.js
import axios from 'axios';
import { theme } from "../core/theme.js";

const BASE_URL = 'https://elysiatools.com';

let handler = async (m, { conn, usedPrefix, command }) => {

    try {
        await m.react("⏳");

        if (!m.quoted) {
            return conn.reply(m.chat, theme.build([
                { type: 'title', text: '⚠️ تنبيه' },
                { type: 'spacer' },
                { type: 'info', label: '📌', value: 'قم بالرد على الاستيكر' },
                { type: 'info', label: 'مثال', value: `${usedPrefix + command}` }
            ]), m);
        }

        let quoted = m.quoted;
        let mime = quoted.mimetype || quoted.msg?.mimetype || "";

        if (!/(webp|image)/.test(mime)) {
            return conn.reply(m.chat, theme.build([
                { type: 'title', text: '❌ خطأ' },
                { type: 'spacer' },
                { type: 'info', label: '❗', value: 'الملف غير مدعوم (استيكر أو صورة فقط)' }
            ]), m);
        }

        let media = await quoted.download();

        if (!media || media.length < 100) {
            throw new Error("الملف تالف أو فارغ");
        }

        await m.reply(theme.build([
            { type: 'title', text: '🔄 جاري التحويل' },
            { type: 'info', label: '⏳', value: 'جاري رفع الملف وتحويله... يرجى الانتظار' }
        ]));

        // 1. رفع الملف
        const formData = new FormData();
        const blob = new Blob([media], { type: mime });
        formData.append('file', blob, 'image.webp');

        const uploadRes = await axios.post(`${BASE_URL}/upload/animated-webp-apng-to-mp4`, formData, {
            headers: { 'Content-Type': 'multipart/form-data' }
        });

        let filePath = uploadRes.data.filePath;
        if (!filePath) {
            console.error("Upload response:", uploadRes.data);
            throw new Error("فشل رفع الملف إلى الخادم");
        }

        // 2. التحويل - استخدم الرابط ده بالضبط
        const convertRes = await axios.post(`${BASE_URL}/en/api/tools/animated-webp-apng-to-mp4`, {
            imageFile: filePath,
            fps: 30,
            quality: 'medium'
        }, {
            headers: { 'Content-Type': 'application/json' }
        });

        // 3. استخراج رابط الفيديو - من convertRes.data.data.filePath
        let resultUrl = convertRes.data?.data?.filePath;
        if (!resultUrl) {
            console.error("Convert response:", convertRes.data);
            throw new Error("فشل الحصول على رابط الفيديو بعد التحويل");
        }

        // تجهيز الرابط الكامل
        if (resultUrl.startsWith('/')) {
            resultUrl = BASE_URL + resultUrl;
        } else if (!resultUrl.startsWith('http')) {
            resultUrl = BASE_URL + '/' + resultUrl;
        }

        // 4. تحميل الفيديو
        const videoRes = await axios.get(resultUrl, {
            responseType: 'arraybuffer',
            timeout: 60000
        });

        const videoBuffer = Buffer.from(videoRes.data);

        if (!videoBuffer || videoBuffer.length < 5000) {
            throw new Error("الملف الناتج تالف");
        }

        await m.react("✅");

        await conn.sendMessage(m.chat, {
            video: videoBuffer,
            mimetype: "video/mp4",
            fileName: "converted.mp4",
            caption: theme.build([
                { type: 'title', text: '✅ تم التحويل بنجاح' },
                { type: 'spacer' },
                { type: 'info', label: '📹', value: 'تم تحويل الاستيكر إلى فيديو' },
                { type: 'info', label: '📦', value: 'الحجم: ' + (videoBuffer.length / 1024).toFixed(2) + ' كيلوبايت' }
            ])
        }, { quoted: m });

    } catch (err) {
        await m.react("❌");
        console.error("Full Error:", err);

        let errorMsg = err.message || 'حدث خطأ غير متوقع';
        
        if (err.response?.data) {
            if (typeof err.response.data === 'string') errorMsg = err.response.data;
            else if (err.response.data.error) errorMsg = err.response.data.error;
            else if (err.response.data.message) errorMsg = err.response.data.message;
            else errorMsg = JSON.stringify(err.response.data);
        }

        conn.reply(m.chat, theme.build([
            { type: 'title', text: '❌ فشل التنفيذ' },
            { type: 'spacer' },
            { type: 'info', label: '⚠️', value: errorMsg.slice(0, 150) }
        ]), m);
    }
};

handler.help = ["لفيديو"];
handler.tags = ["sticker"];
handler.command = /^(لفيديو|tomp4|لمقطع|لفديو)$/i;

export default handler;