import {WAMessageStubType} from '@whiskeysockets/baileys'
import PhoneNumber from 'awesome-phonenumber'
import chalk from 'chalk'
import {watchFile} from 'fs'
import '../settings.js'

const terminalImage = global.opts['img'] ? require('terminal-image') : ''
const urlRegex = (await import('url-regex-safe')).default({strict: false})

export default async function (m, conn = {user: {}}) {
    // ✅ التأكد من وجود m.sender قبل استخدامه
    if (!m || !m.sender) {
        console.log(chalk.red('[!] رسالة بدون مرسل، تم تخطي الطباعة'))
        return
    }

    let name_user
    let senderJid = m.sender || ''
    let senderNumber = senderJid.replace('@s.whatsapp.net', '')
    
    // ✅ الحصول على اسم المرسل بشكل آمن
    let _name = 'مجهول'
    try {
        if (conn.getName && senderJid) {
            _name = (await conn.getName(senderJid)) || 'مجهول'
        }
    } catch (e) {
        console.log('خطأ في جلب اسم المرسل:', e.message)
    }
    
    // ✅ معالجة رقم الهاتف بشكل آمن
    let senderPhone = ''
    try {
        senderPhone = PhoneNumber('+' + senderNumber).getNumber('international') || ''
    } catch (e) {
        senderPhone = senderNumber
    }
    
    let sender = senderPhone === undefined ? '' : senderPhone + (_name == senderPhone ? '' : ' ~' + _name)

    // ✅ الحصول على اسم المجموعة/الدردشة بشكل آمن
    let chat = ''
    try {
        if (conn.getName && m.chat) {
            chat = await conn.getName(m.chat)
        }
    } catch (e) {
        chat = m.chat || ''
    }

    // ✅ طباعة الصورة إذا وجدت (بنفس الطريقة القديمة)
    let img
    try {
        if (global.opts['img'] && m.mtype && /sticker|image/gi.test(m.mtype) && m.download) {
            img = await terminalImage.buffer(await m.download())
        }
    } catch (e) {
        console.error(e)
    }

    // ✅ حساب حجم الملف (بنفس الطريقة القديمة)
    let filesize = (m.msg
        ? m.msg.vcard
            ? m.msg.vcard.length
            : m.msg.fileLength
                ? m.msg.fileLength.low || m.msg.fileLength
                : m.msg.axolotlSenderKeyDistributionMessage
                    ? m.msg.axolotlSenderKeyDistributionMessage.length
                    : m.text
                        ? m.text.length
                        : 0
        : m.text
            ? m.text.length
            : 0) || 0

    // ✅ بيانات المستخدم من قاعدة البيانات (إذا وجدت)
    let user = (global.db?.data?.users && m.sender) ? global.db.data.users[m.sender] : {}
    if (!user) user = {}

    // ✅ رقم البوت
    let me = ''
    try {
        let botJid = conn.user?.jid || ''
        me = PhoneNumber('+' + botJid.replace('@s.whatsapp.net', '')).getNumber('international') || ''
    } catch (e) {
        me = ''
    }

    // ✅ التعامل مع messageStubParameters
    name_user = (m.messageStubParameters && Array.isArray(m.messageStubParameters))
        ? m.messageStubParameters
            .map((jid) => {
                if (!jid) return ''
                try {
                    let usuario_info = conn.decodeJid ? conn.decodeJid(jid) : jid
                    let name_info = (conn.getName && jid) ? conn.getName(jid) : ''
                    return chalk.bold(`${name_info ? name_info : 'Someone'}`)
                } catch (e) {
                    return ''
                }
            })
            .filter(Boolean)
            .join(', ')
        : ''

    // ✅ الطباعة الأساسية (مع تحقق من وجود البيانات)
    console.log(
        `
╭━━━━━━━━━━━━━━⊜
┃ ❖ ${chalk.white.bold('Bot:')} ${chalk.red.bold('%s')} 
┃ ❖ ${chalk.white.bold('Time:')} ${chalk.black.bgRed('%s')}
┃ ❖ ${chalk.white.bold('Action:')} ${chalk.red('%s')}
┃ ❖ ${chalk.white.bold('User:')} ${chalk.white('%s')} / ${chalk.bgRed.bold(user.role?.replace(/\*/g, '') || 'USER')} / Premium » ${user?.premiumTime > 0 ? '✅' : '❌'}
┃ ❖ ${chalk.white.bold('Resources:')} ${chalk.yellow('%s%s')}
┃ ❖ %s
┃ ❖ ${chalk.white.bold('Msg size:')} ${chalk.red('%s (%s %sB)')}
┃ ❖ ${chalk.white.bold('Msg type:')} ${chalk.bgRed.bold('[%s]')}\n%s
╰━━━━━━━━━━━━━━⊜`.trim(),
        (me || 'Unknown') + (conn.user.name == undefined ? '' : ' ~' + conn.user.name) + `${conn.user?.jid == global.conn?.user?.jid ? '' : ' [SUB BOT]'}`,
        (m.messageTimestamp ? new Date(1000 * (m.messageTimestamp.low || m.messageTimestamp)) : new Date()).toTimeString(),
        await formatMessageStubType(m.messageStubType, name_user),
        sender || 'Unknown',
        '',
        `⬆️ ${user.level || 0} / ⭐ ${user.exp || 0} / 🔮 ${user.limit || 0} / 🪙 ${user.money || 0}`,
        m.chat && m.chat.includes('@s.whatsapp.net')
            ? `${chalk.white.bold('Private:')} ${chalk.redBright(`${m.sender || '?'} ~${user.name || _name}`)}`
            : m.chat && m.chat.includes('@g.us')
                ? `${chalk.white.bold('Group:')} ${chalk.redBright(`${m.chat} ~${chat || 'Unknown'}`)}`
                : m.chat && m.chat.includes('@newsletter')
                    ? `${chalk.white.bold('Channel:')} ${chalk.redBright(`${m.chat} ~${chat || 'Unknown'}`)}`
                    : '',
        filesize,
        filesize === 0 ? 0 : (filesize / 1009 ** Math.floor(Math.log(filesize) / Math.log(1000))).toFixed(1),
        ['', ...'KMGTP'][Math.floor(Math.log(filesize) / Math.log(1000))] || '',
        await formatMessageTypes(m.mtype) || 'Not specified',
        (m.message?.extendedTextMessage?.contextInfo?.quotedMessage && m.message?.extendedTextMessage?.contextInfo?.participant)
            ? (m.message?.extendedTextMessage?.contextInfo?.participant == m.sender
                ? '┃ ❖ ' + chalk.red(`${_name || 'This user'}`) + ' replied to their own message.'
                : '┃ ❖ ' +
                  chalk.red(`${_name || 'This user'}`) +
                  (!m.message?.extendedTextMessage?.contextInfo?.participant.includes('newsletter')
                      ? ' replied to ' +
                        chalk.red(`${(await conn.getName(m.message?.extendedTextMessage?.contextInfo?.participant)) || m.message?.extendedTextMessage?.contextInfo?.participant || 'Unknown user'}`)
                      : ' sent message in channel'))
            : ''
    )

    if (img) console.log(img.trimEnd())
    
    if (typeof m.text === 'string' && m.text) {
        let log = m.text.replace(/\u200e+/g, '')
        let mdRegex = /(?<=(?:^|[\s\n])\S?)(?:([*_~`])(?!`)(.+?)\1|```((?:.|[\n\r])+?)```|`([^`]+?)`)(?=\S?(?:[\s\n]|$))/g
        let mdFormat = (depth = 4) => (_, type, text, monospace) => {
            let types = {
                _: 'italic',
                '*': 'bold',
                '~': 'strikethrough',
                '`': 'bgGray'
            }
            text = text || monospace
            let formatted = !types[type] || depth < 1 ? text : chalk[types[type]](text.replace(/`/g, '').replace(mdRegex, mdFormat(depth - 1)))
            return formatted
        }
        log = log.replace(mdRegex, mdFormat(4))
        log = log.split('\n').map((line) => {
            if (line.trim().startsWith('>')) {
                return chalk.bgRed.dim(line.replace(/^>/, '┃'))
            } else if (/^([1-9]|[1-9][0-9])\./.test(line.trim())) {
                return line.replace(/^(\d+)\./, (match, number) => {
                    const padding = number.length === 1 ? '  ' : ' '
                    return padding + number + '.'
                })
            } else if (/^[-*]\s/.test(line.trim())) {
                return line.replace(/^[*-]/, '  •')
            }
            return line
        }).join('\n')
        if (log.length < 1024)
            log = log.replace(urlRegex, (url, i, text) => {
                let end = url.length + i
                return i === 0 || end === text.length || (/^\s$/.test(text[end]) && /^\s$/.test(text[i - 1])) ? chalk.redBright(url) : url
            })
        log = log.replace(mdRegex, mdFormat(4))
        if (m.mentionedJid && Array.isArray(m.mentionedJid)) {
            for (let user of m.mentionedJid) {
                if (user) {
                    let userName = '?'
                    try { userName = await conn.getName(user) } catch {}
                    log = log.replace('@' + user.split`@`[0], chalk.redBright('@' + userName))
                }
            }
        }
        console.log(m.error != null ? chalk.red(log) : m.isCommand ? chalk.red(log) : chalk.red(log))
    }

    if (m.messageStubParameters && Array.isArray(m.messageStubParameters)) {
        let stubParams = []
        for (let jid of m.messageStubParameters) {
            if (jid) {
                try {
                    jid = conn.decodeJid ? conn.decodeJid(jid) : jid
                    let name = (conn.getName && jid) ? await conn.getName(jid) : ''
                    const phoneNumber = PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international') || ''
                    stubParams.push(name ? chalk.gray(`${phoneNumber} (${name})`) : '')
                } catch (e) {
                    stubParams.push('')
                }
            }
        }
        console.log(stubParams.filter(Boolean).join(', '))
    }

    if (/document/i.test(m.mtype)) console.log(`📄 ${m.msg?.fileName || m.msg?.displayName || 'Document'}`)
    else if (/ContactsArray/i.test(m.mtype)) console.log(`👥 ${' ' || ''}`)
    else if (/contact/i.test(m.mtype)) console.log(`👤 ${m.msg?.displayName || ''}`)
    else if (/audio/i.test(m.mtype) && m.msg?.seconds) {
        const duration = m.msg.seconds
        console.log(`${m.msg.ptt ? '🎤 (PTT ' : '🎵 ('}AUDIO) ${Math.floor(duration / 60).toString().padStart(2, 0)}:${(duration % 60).toString().padStart(2, 0)}`)
    }
    console.log()
}

let file = global.__filename(import.meta.url)
watchFile(file, () => {
    console.log(chalk.redBright("Update 'core/print.js'"))
})

async function formatMessageStubType(messageStubType, name_user) {
    switch (messageStubType) {
        case 0: return 'Unknown'
        case 1: return 'Revoked'
        case 2: return 'Encrypted text'
        case 20: return 'Group created'
        case 21: return 'Group name changed'
        case 22: return 'Group icon changed'
        case 23: return 'New group link'
        case 24: return 'New group description'
        case 25: return 'Group restrictions changed'
        case 26: return 'Who can send messages configured'
        case 27: return `${name_user || 'Someone'} joined the group`
        case 28: return `${name_user || 'Someone'} was removed from group`
        case 29: return `${name_user || 'Someone'} is new admin`
        case 30: return `${name_user || 'Someone'} is no longer admin`
        case 31: return `${name_user || 'Someone'} was invited to group`
        case 32: return `${name_user || 'Someone'} left the group`
        case 145: return `"Approve new members" configured`
        case 171: return `"Add other members" configured`
        default: return messageStubType
    }
}

async function formatMessageTypes(messageType) {
    switch (messageType) {
        case 'conversation': return 'Conversation'
        case 'imageMessage': return 'Image'
        case 'contactMessage': return 'Contact'
        case 'locationMessage': return 'Location'
        case 'extendedTextMessage': return 'Text'
        case 'documentMessage': return 'Document'
        case 'audioMessage': return 'Audio'
        case 'videoMessage': return 'Video'
        case 'call': return 'Call'
        case 'chat': return 'Chat'
        case 'protocolMessage': return 'Encrypted'
        case 'contactsArrayMessage': return 'Contacts list'
        case 'stickerMessage': return 'Sticker'
        case 'groupInviteMessage': return 'Group invite'
        case 'listMessage': return 'List'
        case 'viewOnceMessage': return 'View once'
        case 'buttonsMessage': return 'Buttons'
        case 'interactiveMessage': return 'Interactive'
        case 'reactionMessage': return 'Reaction'
        case 'pollCreationMessage': return 'Poll creation'
        default: return messageType || 'Not specified'
    }
}